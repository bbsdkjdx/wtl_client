import ctypes
def wnd2htmldoc(hwn):
    import win32com.client,pythoncom
    try:
        result=ctypes.c_uint32(0)
        msg = ctypes.windll.user32.RegisterWindowMessageW('WM_HTML_GETOBJECT')
        ret= ctypes.windll.user32.SendMessageTimeoutW(hwn, msg, 0, 0, 2, 1000,ctypes.byref(result))
        ob = pythoncom.ObjectFromLresult(result.value, pythoncom.IID_IDispatch, 0)
        doc = win32com.client.dynamic.Dispatch(ob)
        return doc
    except Exception as exp:
        return None

def shell_execute(cmd,show=0,block=0):
    class _SHELLEXECUTEINFO (ctypes.Structure):
        """docstring for _SHELLEXECUTEINFO """
        _fields_ = [("cbSize", ctypes.c_uint32),
                ("fMask", ctypes.c_uint32),
                ("HWND", ctypes.c_uint32),
                ("lpVerb",ctypes.c_wchar_p),
                ("lpFile", ctypes.c_wchar_p),
                ("lpParameters", ctypes.c_wchar_p),
                ("lpDirectory", ctypes.c_wchar_p),
                ("nShow", ctypes.c_uint32),
                ("hInstApp", ctypes.c_uint32),
                ("lpIDList", ctypes.c_void_p),
                ("lpClass", ctypes.c_wchar_p),
                ("hkeyClass", ctypes.c_uint32),
                ("dwHotKey", ctypes.c_uint32),
                ("DUMMYUNIONNAME", ctypes.c_uint32),
                ("hProcess", ctypes.c_uint32)]
    se=ctypes.windll.shell32.ShellExecuteExW
    wfso=ctypes.windll.kernel32.WaitForSingleObject
    para=_SHELLEXECUTEINFO()
    para.cbSize=ctypes.sizeof(para)
    para.fMask=0x40
    para.HWND=0
    para.lpVerb='open'
    para.lpFile='explorer.exe' if show else cmd
    para.lpParameters=r'/select,'+cmd if show else 0
    para.lpDirectory=0
    para.nShow=5
    para.hInstApp=0
    para.lpIDList=0
    para.lpClass=0
    para.hkeyClass=0
    para.dwHotKey=0
    para.DUMMYUNIONNAME=0
    se(ctypes.byref(para))
    if block:
      wfso(para.hProcess,0xffffffff)

def mouse2wnd():
    pos=ctypes.c_uint64()
    ctypes.windll.user32.GetCursorPos(ctypes.byref(pos))
    hwnd=ctypes.windll.user32.WindowFromPoint(pos)
    return hwnd

def wnd2pid(wnd):
    pid=ctypes.c_uint32()
    ctypes.windll.user32.GetWindowThreadProcessId(wnd,ctypes.byref(pid))
    return pid.value

def get_my_pid():
    ret=ctypes.windll.kernel32.GetCurrentProcessId()
    return ret

def pid2fn(pid):
     handle=ctypes.windll.kernel32.OpenProcess(0x1F0FFF,0,pid)
     buf=ctypes.create_unicode_buffer(256)
     ctypes.windll.psapi.GetModuleFileNameExW(handle,0,buf,256)
     return buf.value

def killpid(pid):
    handle=ctypes.windll.kernel32.OpenProcess(0x1F0FFF,0,pid)
    ctypes.windll.kernel32.TerminateProcess(handle,0)

def inject_dll(pid,fn_dll):
    kernel32=ctypes.windll.kernel32
    OpenProcess=kernel32.OpenProcess
    VirtualAllocEx=kernel32.VirtualAllocEx
    WriteProcessMemory=kernel32.WriteProcessMemory
    WaitForSingleObject=kernel32.WaitForSingleObject
    CloseHandle=kernel32.CloseHandle
    GetProcAddress=kernel32.GetProcAddress
    CreateRemoteThread=kernel32.CreateRemoteThread
    GetModuleHandleW=kernel32.GetModuleHandleW
    GetWindowThreadProcessId=ctypes.windll.user32.GetWindowThreadProcessId
    LLW_addr=GetProcAddress(GetModuleHandleW('kernel32.dll'),b'LoadLibraryW')
    PROCESS_ALL_ACCESS = 0x001F0FFF
    MEM_COMMIT=0x1000
    PAGE_READWRITE=4

    hp=OpenProcess(PROCESS_ALL_ACCESS,0,pid)
    if hp==0:
        raise Exception('OpenProcess fail!')
    rmt_addr=VirtualAllocEx(hp,0,256,MEM_COMMIT,PAGE_READWRITE)
    if rmt_addr==0:
        raise Exception('VirtualAllocEx fail!')
    n_w=ctypes.c_int32(0)
    WriteProcessMemory(hp,rmt_addr,fn_dll,len(fn_dll)*2+2,ctypes.byref(n_w))
    if n_w==0:
        raise Exception('WriteProcessMemory fail!')
    hthd=CreateRemoteThread(hp,0,0,LLW_addr,rmt_addr,0,0)
    return hthd

def wnd2text(wnd):
    buf=ctypes.create_unicode_buffer(256)
    ctypes.windll.user32.GetWindowTextW(wnd,buf,256)
    return buf.value

def get_fore_wnd():
    return ctypes.windll.user32.GetForegroundWindow()

def topmost_wnd(wnd,top=1):
    ctypes.windll.user32.SetWindowPos(wnd,-1 if top else -2,0,0,0,0,3)

def select_file(isOpen=1,file_hint='',fileFilter=''):
	class tagOFN(ctypes.Structure):
		_fields_=[
			("lStructSize",ctypes.c_uint32),
			("hwndOwner",ctypes.c_uint32),
			("hInstance",ctypes.c_uint32),
			("lpstrFilter",ctypes.c_wchar_p),
			("lpstrCustomFilter",ctypes.c_wchar_p),
			("nMaxCustFilter",ctypes.c_uint32),
			("nFilterIndex",ctypes.c_uint32),
			("lpstrFile",ctypes.c_wchar_p),
			("nMaxFile",ctypes.c_uint32),
			("lpstrFileTitle",ctypes.c_wchar_p),
			("nMaxFileTitle",ctypes.c_uint32),
			("lpstrInitialDir",ctypes.c_wchar_p),
			("lpstrTitle",ctypes.c_wchar_p),
			("Flags",ctypes.c_uint32),
			("nFileOffset",ctypes.c_uint16),
			("nFileExtension",ctypes.c_uint16),
			("lpstrDefExt",ctypes.c_wchar_p),
			("lCustData",ctypes.c_uint32),
			("lpfnHook",ctypes.c_uint32),
			("lpTemplateName",ctypes.c_wchar_p),
			]
	buf=ctypes.create_unicode_buffer(500)
	buf.value=file_hint
	ofn=tagOFN()
	ofn.lStructSize=ctypes.sizeof(tagOFN)
	ofn.hwndOwner=get_fore_wnd()
	ofn.lpstrFile=ctypes.cast(buf,ctypes.c_wchar_p)
	ofn.nMaxFile=500
	ofn.lpstrFilter=fileFilter
	ofn.nFilterIndex=1
	ofn.lpstrFileTitle=0
	ofn.nMaxFileTitle=0
	ofn.lpstrInitialDir=0
	if isOpen:
		fun=ctypes.windll.comdlg32.GetOpenFileNameW
	else:
		fun=ctypes.windll.comdlg32.GetSaveFileNameW
	if fun(ctypes.byref(ofn)):
		return ofn.lpstrFile
	return ''

def select_folder(title=''):
    class BROWSEINFO(ctypes.Structure):
        _fields_=[
            ("hwndOwner",ctypes.c_uint32),
            ("pidlRoot",ctypes.c_uint32),
            ("pszDisplayName",ctypes.c_wchar_p),
            ("lpszTitle",ctypes.c_wchar_p),
            ("ulFlags",ctypes.c_uint32),
            ("lpfn",ctypes.c_uint32),
            ("lParam",ctypes.c_uint32),
            ("iImage",ctypes.c_uint32)
            ]
    buf=ctypes.create_unicode_buffer(500)
    brio=BROWSEINFO()
    brio.hwndOwner=get_fore_wnd()
    brio.pidlRoot=0
    brio.pszDisplayName=ctypes.cast(buf,ctypes.c_wchar_p)
    brio.lpszTitle=title
    #brio.ulFlags=
    brio.lpfn=0
    brio.lParam=0
    brio.iImage=0
    ret=ctypes.windll.shell32.SHBrowseForFolderW(ctypes.byref(brio))
    if not ret:
        return ''
    ctypes.windll.shell32.SHGetPathFromIDListW(ret,buf)
    return buf.value

def get_last_error_message():
	buf=ctypes.c_wchar_p(0)
	fmtmsg=ctypes.windll.kernel32.FormatMessageW
	eid=ctypes.windll.kernel32.GetLastError()
	fmtmsg(0x1100,0,eid,0,ctypes.byref(buf),0,0)
	return buf.value

def get_pids():
	BUF=ctypes.c_uint32*500
	buf=BUF()
	ret=ctypes.c_uint32()
	ctypes.windll.psapi.EnumProcesses(buf,2000,ctypes.byref(ret))
	se=set(buf)
	se.remove(0)
	return se
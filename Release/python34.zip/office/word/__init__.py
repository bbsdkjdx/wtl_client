#wps文字：'kwps.application'
from win32com.client import DispatchEx as _dispatch
class Word(object):
    """The wrapper class of ms word COM interface"""
    from .document import Document
    def __init__(self, visible):
        self._raw=_dispatch('Word.Application')
        self._raw.Visible=visible

    def quit(self):
        for x in self.docs:
            x._raw.Close(0)
        self._raw.Quit()

    @property
    def raw(self):
        return self._raw

    @property
    def docs(self):
        return [self.Document(x,self) for x in self._raw.Documents]

    def open(self,fn):
        _dk=self._raw.Documents.Open(fn)
        return self.Document(_dk,self)

    def new(self):
        _dk=self._raw.Documents.Add()
        return self.Document(_dk,self)
    
    @property
    def selection(self):
        return self._raw.Selection.text

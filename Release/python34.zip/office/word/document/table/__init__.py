class Table(object):
    from .cell import Cell
    def __init__(self,_tb):
        self._raw=_tb
    @property
    def raw(self):
        return self._raw
    def get_cell(self,row_1,col_1):
        return self.Cell(self._raw.Cell(row_1,col_1))

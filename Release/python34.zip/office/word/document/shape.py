class Shape(object):
    """docstring for Shape"""
    def __init__(self, _shp):
        self._raw=_shp
    @property
    def raw(self):
        return self._raw
    @property
    def text(self):
        return self._raw.TextFrame.TextRange.Text
    @text.setter
    def text(self,txt):
        self._raw.TextFrame.TextRange.Text=txt

    def adjust_spacing(self):
        n_line=self._raw.TextFrame.TextRange.ComputeStatistics(1)
        t_b=self._raw.TextFrame.MarginBottom+self._raw.TextFrame.MarginTop
        _pf=self._raw.TextFrame.TextRange.ParagraphFormat
        _pf.LineSpacingRule=4
        _pf.LineSpacing=(self._raw.Height-t_b)/n_line
        return _pf.LineSpacing

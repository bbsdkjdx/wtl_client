#wps演示：'kwpp.application'
from win32com.client import DispatchEx as _dispatch
class PowerPoint(object):
    from .presentation import Presentation
    def __init__(self,visible):
        self._raw=_dispatch('PowerPoint.Application')
        if visible:
            self._raw.Visible=1

    def __del__(self):
        for x in self._raw.Presentations:
            x.Close()
        self._raw.Quit()

    @property
    def raw(self):
        return self._raw

    @property
    def presentations(self):
        return [self.Presentation(x,self) for x in self.raw.Presentations]

    def new(self):
        _pre=self.raw.Presentations.Add()
        return self.Presentation(_pre,self)

    def open(self,fn):
        _pre=self.raw.Presentations.Open(fn)
        return self.Presentation(_pre,self)

#wps表格：'ket.application'
from win32com.client import DispatchEx as _dispatch
class Excel(object):
    from .book import Book
    """An Excel application instance"""
    def __init__(self, visible):
        self._raw=_dispatch('Excel.Application')
        self._raw.Visible=visible

    def __del__(self):
        for x in self.books:
            x.close()
        self._raw.Quit()

    @property
    def raw(self):
        return self._raw

    @property
    def selection(self):
        return self._raw.Selection()
    @selection.setter
    def selection(self,dat):
        self._raw.Selection=dat

    @property
    def range(self,s):
        return self._raw.Range(s)

    @property
    def visible(self):
        return self._raw.Visible

    @visible.setter
    def visible(self,visible):
        self._raw.Visible=visible

    @property
    def silence(self):
        return not self._raw.DisplayAlerts

    @silence.setter
    def silence(self,slc):
        self._raw.DisplayAlerts=not slc

    def get_active_book(self):
        raw_bk=self._raw.ActiveWorkBook
        return self.Book(raw_bk,self)

    def get_active_sheet(self):
        raw_st=self._raw.ActiveSheet
        return self.Book.Sheet(raw_st,self.get_active_book())


    @property
    def books(self):
        return [self.Book(x,self) for x in self._raw.Workbooks]

    def open(self,fn):
        _bk=self._raw.Workbooks.Open(fn)
        return self.Book(_bk,self)

    def new(self):
        _bk=self._raw.Workbooks.Add()
        return self.Book(_bk,self)

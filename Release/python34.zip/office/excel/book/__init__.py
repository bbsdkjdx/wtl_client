class Book(object):
    """docstring for Book"""
    from .sheet import Sheet
    def __init__(self, _book,excel):
        self._raw=_book
        self._excel=excel

    def __del__(self):
        pass

    def __repr__(self):
        return super().__repr__()+'name="'+self.name+'"'

    @property
    def raw(self):
        return self._raw
    @property
    def name(self):
        return self._raw.name

    @property
    def sheets(self):
        return [self.Sheet(x,self) for x in self._raw.Sheets]

    def save(self):
        if self._raw==None:
            return
        self._raw.Save()

    def saveas(self,fn):
        if self._raw==None:
            return
        self._raw.SaveAs(fn)

    def close(self):
        if self._raw:
            self._raw.Close(0)
            self._raw=None

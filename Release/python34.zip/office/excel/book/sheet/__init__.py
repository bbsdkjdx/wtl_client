class Sheet(object):
    """docstring for Sheet"""
    def __init__(self, sht,book):
        self._raw = sht
        self._book=book
    def __repr__(self):
        return '%s:name=%s.%s'%(super().__repr__(),self._book.name,self.name)

    @property
    def raw(self):
        return self._raw
    @property
    def n_rows(self):
        return self._raw.UsedRange.Rows.Count

    @property
    def n_cols(self):
        return self._raw.UsedRange.Columns.Count

    def get_text(self,row,col):
        return self._raw.Cells(row,col).Value

    def set_text(self,row,col,txt):
        self._raw.Cells(row,col).Value=txt

    def replace(self,s_old,s_new):
    	self._raw.Cells.Replace(s_old,s_new)

    @property
    def name(self):
        return self._raw.Name

    @name.setter
    def name(self,nm):
        self._raw.Name=nm

    def print_out(self):
        self._raw.PrintOut()

    def copy_before(self,st=None):
        if st:
            self._raw.Copy(st._raw)
        else:
            self._raw.Copy()
        return self._book._excel.get_active_sheet()

    def move_before(self,st=None):
        if st:
            self._raw.Move(st._raw)
        else:
            self._raw.Move()
        return self._book._excel.get_active_sheet()

    def save_as(self,fn):
        st=self.copy_before()
        st._book.saveas(fn)
        st._book.close()

    def delete(self):
        self._raw.Delete()
